# 📊 Project Portfolio & Analytics Dashboard

A professional full-stack application designed for managing and visualizing a project portfolio. This application leverages a **Node.js/Express** backend to serve a high-performance **React** frontend, providing a unified, single-port production environment.

---

## 🚀 Quick Start (One-Terminal Setup)

Because the frontend is pre-built and hosted by the backend, you only need to run the server to view the full application.

1. **Navigate to the Server directory:**
   ```bash
   cd server

Install dependencies:

Bash
npm install
Launch the application:

Bash
npm start
View in Browser:
Open http://localhost:5000

🛠️ Tech Stack
Frontend (Source located in /client)
React (Vite): Reactive UI development.

Tailwind CSS: Modern utility-first styling.

ECharts (Apache): Advanced data visualization for portfolio analytics.

Material UI (MUI): Accessible form components and data grids.

Lucide React: Clean, consistent iconography.

Backend & Database (Located in /server)
Node.js & Express: Serving both the REST API and the static React dist build.

SQLite3: Relational database for persistent project storage.

Path/URL: Used for cross-platform file path resolution.

🧠 Key Features & Approach
1. Unified Production Hosting
To simplify deployment and satisfy performance requirements, the React application is compiled into a production-ready dist folder. The Express server uses express.static to serve these files, providing a seamless user experience on a single port (5000).

2. Full CRUD Lifecycle
The application supports the complete Project lifecycle:

Create: Add projects with validation (Project name, Bureau, and Dates).

Read: Filterable data table with status-based color coding.

Update: Toggle-controlled "Edit Mode" to modify existing records, including financial data.

Delete: Secure deletion with an Alert Confirmation modal to prevent accidental data loss.

3. Data-Driven Dashboard (Requirement #2)
The dashboard provides immediate business intelligence:

Financial Overview: Tracks "Active Allocation" (In Progress spend) vs. "Delivered Value" (Completed project budgets).

Deadline Tracker: Automatically calculates date proximity to flag projects as "Overdue" or "Due Soon" (within 14 days).

Bureau Allocation: Visualizes resource load across departments using stacked bar charts.

4. Database Schema Modification
To meet the requirement for Budget Totals (which was missing from the provided schema), I modified the SQLite database.

SQL Action: ALTER TABLE projects ADD COLUMN budget REAL DEFAULT 0.0;

This allows for the financial tracking and progress-bar visualizations found in the "Financial Overview" widget.

