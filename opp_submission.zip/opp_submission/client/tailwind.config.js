
/** @type {import('tailwindcss').Config} */
module.exports = {
    darkMode: ["class"],
    content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
  	extend: {
  		colors: {
  			primary: {
  				DEFAULT: 'hsl(var(--primary))',
  				foreground: 'hsl(var(--primary-foreground))'
  			},
  			secondary: {
  				DEFAULT: 'hsl(var(--secondary))',
  				foreground: 'hsl(var(--secondary-foreground))'
  			},
  			accent: {
  				DEFAULT: 'hsl(var(--accent))',
  				foreground: 'hsl(var(--accent-foreground))'
  			},
  			warning: '#E69F00',
			primary: '#50c194',
  			error: '#D32F2F',
  			button: '#57bd9d',
  			bgLight: '#F7F7F7',
  			cardBg: '#FFFFFF',
  			textPrimary: '#333333',
  			textSecondary: '#555555',
  			textBlack: '#000000',
  			textWhite: '#FFFFFF',
  			headerBottom: '#5a6770',
  			headerLeft: '#57bc9c',
  			headerTop: '#3a4750',
  			textBottom: '#D2D8DB',
  			searchBar: '#5d6874',
  			dark: '#c43335',
  			light: '#D17577',
  			sidebar: '#303f49',
  			login: '#394856',
  			titleBox: '#72d7ae',
  			background: 'hsl(var(--background))',
  			foreground: 'hsl(var(--foreground))',
  			card: {
  				DEFAULT: 'hsl(var(--card))',
  				foreground: 'hsl(var(--card-foreground))'
  			},
  			popover: {
  				DEFAULT: 'hsl(var(--popover))',
  				foreground: 'hsl(var(--popover-foreground))'
  			},
  			muted: {
  				DEFAULT: 'hsl(var(--muted))',
  				foreground: 'hsl(var(--muted-foreground))'
  			},
  			destructive: {
  				DEFAULT: 'hsl(var(--destructive))',
  				foreground: 'hsl(var(--destructive-foreground))'
  			},
  			border: 'hsl(var(--border))',
  			input: 'hsl(var(--input))',
  			ring: 'hsl(var(--ring))',
  			chart: {
  				'1': 'hsl(var(--chart-1))',
  				'2': 'hsl(var(--chart-2))',
  				'3': 'hsl(var(--chart-3))',
  				'4': 'hsl(var(--chart-4))',
  				'5': 'hsl(var(--chart-5))'
  			}
  		},
  		fontFamily: {
  			heading: [
  				'Raleway',
  				'Open Sans',
  				'Helvetica Neue',
  				'sans-serif'
  			],
  			body: [
  				'Open Sans',
  				'Helvetica Neue',
  				'sans-serif'
  			]
  		},
  		fontSize: {
  			xs: '0.75rem',
  			sm: '0.875rem',
  			base: '1rem',
  			lg: '1.125rem',
  			xl: '1.5rem',
  			'2xl': '2rem'
  		},
  		borderRadius: {
  			lg: 'var(--radius)',
  			md: 'calc(var(--radius) - 2px)',
  			sm: 'calc(var(--radius) - 4px)'
  		}
  	}
  },
  plugins: [require("tailwindcss-animate")],
};
//  <div className="flex flex-col items-center justify-center min-h-[80vh] bg-[linear-gradient(228deg,rgba(8,153,109,1)_6%,rgba(86,188,157,1)_21%,rgba(63,235,180,1)_49%,rgba(178,212,199,1)_87%,rgba(77,184,139,1)_96%)] px-4 sm:px-6 py-8">
  