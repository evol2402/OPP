import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')

  return {
    plugins: [react()],
    // Dev-only proxy to forward /api to the local backend
    server: {
      proxy: {
        '/api': {
          target: env.VITE_DEV_API_PROXY ?? 'http://localhost:5000',
          changeOrigin: true,
        },
      },
    },
    build: {
      // Help split heavy dependencies and quiet overly large chunk warnings
      chunkSizeWarningLimit: 2000,
      rollupOptions: {
        output: {
          manualChunks: {
            vendor: ['react', 'react-dom', 'react-router-dom'],
            // FIX: Removed 'echarts-for-react' since it is uninstalled
            charts: ['echarts'], 
            lottie: ['lottie-web'],
          },
        },
      },
    },
  }
})