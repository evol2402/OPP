import React, { useEffect, useRef } from "react";
import * as echarts from "echarts";

const ProjectRosePie = ({
  data = [], 
  title = "",
  subtext = "",
  height = 400,
  roseType = "radius", // "radius" | "area" | false
  colors = ['#059669', '#10b981', '#34d399', '#6ee7b7', '#a7f3d0'] // Emerald theme default
}) => {
  const chartRef = useRef(null);
  const chartInstanceRef = useRef(null);

  // 1. Initialize ECharts and handle Window Resize
  useEffect(() => {
    if (chartRef.current && !chartInstanceRef.current) {
      chartInstanceRef.current = echarts.init(chartRef.current);
    }

    const handleResize = () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.resize();
      }
    };

    window.addEventListener("resize", handleResize);
    
    return () => {
      window.removeEventListener("resize", handleResize);
      if (chartInstanceRef.current) {
        chartInstanceRef.current.dispose();
        chartInstanceRef.current = null;
      }
    };
  }, []);

  // 2. Update Chart Options when Data changes
  useEffect(() => {
    const chartInstance = chartInstanceRef.current;
    if (!chartInstance || !data || data.length === 0) return;

    const containerWidth = chartRef.current?.clientWidth || window.innerWidth;
    const isSmallScreen = containerWidth < 640;

    const option = {
      title: {
        text: title,
        subtext: subtext,
        left: "center",
        textStyle: { color: '#1f2937', fontSize: 16, fontWeight: 'bold' }
      },
      tooltip: {
        trigger: "item",
        formatter: "{b} : {c} Projects ({d}%)", // ECharts shorthand: {b}=name, {c}=value, {d}=percent
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        borderColor: '#e5e7eb',
        textStyle: { color: '#374151' }
      },
      legend: {
        show: true,
        type: "scroll",
        orient: "horizontal",
        left: "center",
        bottom: 0,
        itemGap: 15,
      },
      toolbox: {
        show: true,
        feature: {
          saveAsImage: { show: true, title: "Save" },
        },
        right: 10,
        top: 0
      },
      series: [
        {
          name: title,
          type: "pie",
          radius: roseType ? [20, isSmallScreen ? 100 : 130] : [0, isSmallScreen ? 110 : 140],
          center: ["50%", "50%"],
          roseType: roseType || undefined,
          itemStyle: {
            borderRadius: 6,
            borderColor: '#fff',
            borderWidth: 2
          },
          label: {
            show: !isSmallScreen,
            formatter: '{b}\n{c}',
            color: '#4b5563'
          },
          color: colors,
          data: data.sort((a, b) => b.value - a.value), // Sort largest to smallest for better visual flow
        },
      ],
    };

    chartInstance.setOption(option, true);

  }, [data, title, subtext, roseType, colors]);

  // Handle empty state gracefully
  if (!data || data.length === 0) {
    return (
      <div style={{ height, width: "100%" }} className="flex items-center justify-center bg-gray-50 rounded-lg border border-dashed border-gray-300">
        <p className="text-gray-500 font-medium">No data available for this chart</p>
      </div>
    );
  }

  return (
    <div 
      ref={chartRef} 
      style={{ width: "100%", height }} 
      className="transition-all duration-300"
    />
  );
};

export default ProjectRosePie;