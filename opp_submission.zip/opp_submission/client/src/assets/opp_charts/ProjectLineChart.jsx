import React, { useEffect, useRef } from "react";
import * as echarts from "echarts";

const ProjectLineChart = ({
  title = "Project Metrics",
  subtext = "",
  chartData = { labels: [], series: [] }, 
  height = 400,
  colors = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444'], 
  smooth = true,
  showArea = false
}) => {
  const chartRef = useRef(null);
  const chartInstanceRef = useRef(null);

  useEffect(() => {
    if (chartRef.current && !chartInstanceRef.current) {
      chartInstanceRef.current = echarts.init(chartRef.current);
    }

    const handleResize = () => chartInstanceRef.current?.resize();
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      chartInstanceRef.current?.dispose();
      chartInstanceRef.current = null;
    };
  }, []);

  useEffect(() => {
    const chart = chartInstanceRef.current;
    if (!chart || !chartData.labels.length) return;

    const formattedSeries = chartData.series.map((s, idx) => ({
      name: s.name,
      type: "line",
      smooth: smooth,
      symbol: "circle",
      symbolSize: 8,
      data: s.data,
      lineStyle: { width: 4, color: colors[idx % colors.length] },
      itemStyle: { color: colors[idx % colors.length], borderSize: 2, borderColor: '#fff' },
      areaStyle: showArea ? {
        opacity: 0.1,
        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
          { offset: 0, color: colors[idx % colors.length] },
          { offset: 1, color: 'rgba(255,255,255,0)' }
        ])
      } : undefined,
    }));

    const option = {
      title: {
        text: title,
        subtext: subtext,
        textStyle: { color: '#1f2937', fontSize: 16, fontWeight: 'bold' },
        left: 'left'
      },
      tooltip: {
        trigger: "axis",
        backgroundColor: 'rgba(255, 255, 255, 0.98)',
        borderColor: '#e5e7eb',
        textStyle: { color: '#374151' },
        axisPointer: { type: 'cross', label: { backgroundColor: '#6b7280' } }
      },
      legend: {
        bottom: 0,
        icon: 'roundRect'
      },
      grid: {
        left: "2%",
        right: "8%",
        bottom: "12%",
        top: "18%",
        containLabel: true
      },
      xAxis: {
        type: "category",
        boundaryGap: false,
        data: chartData.labels,
        axisLine: { lineStyle: { color: '#9ca3af' } },
        axisTick: { show: false }
      },
      yAxis: {
        type: "value",
        splitLine: { lineStyle: { color: '#f3f4f6', type: 'dashed' } },
        axisLine: { show: false },
        axisTick: { show: false }
      },
      series: formattedSeries
    };

    chart.setOption(option, true);
  }, [chartData, title, subtext, colors, smooth, showArea]);

  if (!chartData.labels.length) {
    return (
      <div style={{ height }} className="flex items-center justify-center bg-gray-50 rounded-lg border border-dashed border-gray-300">
        <p className="text-gray-500 font-medium">No trend data available</p>
      </div>
    );
  }

  return <div ref={chartRef} style={{ width: "100%", height }} />;
};

export default ProjectLineChart;