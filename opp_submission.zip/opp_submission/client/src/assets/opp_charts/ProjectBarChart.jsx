import React, { useEffect, useRef } from "react";
import * as echarts from "echarts";

const ProjectBarChart = ({
  title = "Resource Allocation by Bureau",
  subtext = "",
  chartData = { categories: [], series: [] }, 
  height = 400,
  stacked = true,
  colors = ['#ef4444', '#f97316', '#eab308', '#3b82f6', '#10b981'], // Default to a standard priority palette
}) => {
  const chartRef = useRef(null);
  const chartInstanceRef = useRef(null);

  // 1. Initialize ECharts and handle Window Resize
  useEffect(() => {
    if (chartRef.current && !chartInstanceRef.current) {
      chartInstanceRef.current = echarts.init(chartRef.current);
    }

    const handleResize = () => chartInstanceRef.current?.resize();
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      chartInstanceRef.current?.dispose();
      chartInstanceRef.current = null;
    };
  }, []);

  // 2. Render Chart when data changes
  useEffect(() => {
    const chart = chartInstanceRef.current;
    if (!chart || !chartData || !chartData.categories.length) return;

    // Map the incoming series to ECharts format
    const formattedSeries = chartData.series.map((s, index) => ({
      name: s.name,
      type: "bar",
      stack: stacked ? "total" : undefined,
      barMaxWidth: 60, // Prevents bars from getting comically wide on large screens
      itemStyle: {
        color: colors[index % colors.length],
        borderRadius: stacked ? 0 : [4, 4, 0, 0] // Only round tops if not stacked
      },
      emphasis: {
        focus: "series"
      },
      data: s.data
    }));

    // If stacked, apply border radius to the top of the very last non-zero segment in the stack
    if (stacked && formattedSeries.length > 0) {
      formattedSeries[formattedSeries.length - 1].itemStyle.borderRadius = [4, 4, 0, 0];
    }

    const option = {
      title: {
        text: title,
        subtext: subtext,
        textStyle: { color: '#1f2937', fontSize: 16, fontWeight: 'bold' }
      },
      tooltip: {
        trigger: "axis",
        axisPointer: { type: "shadow" }, // Gives a nice background highlight behind the hovered bar
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        borderColor: '#e5e7eb',
        textStyle: { color: '#374151' }
      },
      legend: {
        show: true,
        bottom: 0,
        itemGap: 20,
      },
      grid: {
        left: "3%",
        right: "4%",
        bottom: 60,
        containLabel: true,
      },
      toolbox: {
        feature: { saveAsImage: { title: "Save" } },
        right: 10,
      },
      xAxis: {
        type: "category",
        data: chartData.categories,
        axisLine: { lineStyle: { color: '#9ca3af' } },
        axisTick: { show: false },
        axisLabel: { 
          color: '#4b5563',
          interval: 0, // Forces all labels to show
          rotate: chartData.categories.length > 5 ? 30 : 0 // Auto-rotates if too many bureaus
        }
      },
      yAxis: {
        type: "value",
        axisLine: { show: false },
        axisTick: { show: false },
        splitLine: { lineStyle: { color: '#f3f4f6', type: 'dashed' } },
      },
      series: formattedSeries,
    };

    chart.setOption(option, true);
  }, [chartData, title, subtext, stacked, colors]);

  // Handle empty state gracefully
  if (!chartData || !chartData.categories || chartData.categories.length === 0) {
    return (
      <div style={{ height, width: "100%" }} className="flex items-center justify-center bg-gray-50 rounded-lg border border-dashed border-gray-300">
        <p className="text-gray-500 font-medium">No bar chart data available</p>
      </div>
    );
  }

  return <div ref={chartRef} style={{ width: "100%", height }} className="transition-all duration-300" />;
};

export default ProjectBarChart;