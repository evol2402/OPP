import React, { Suspense } from "react";
import { Routes, Route, Navigate } from "react-router-dom";

// UI Components
import MainLayout from "./components/layout_components/MainLayout";
import LoadingAnimation from "./components/animation_components/LoadingAnimation";
import NotFoundAnimation from "./components/animation_components/NotFoundAnimation";

// Pages
import Dashboard from "./pages/Dashboard";
import ProjectManager from "./pages/ProjectManager";
import ProfilePage from "./pages/ProfilePage"; // Added your new profile page!

function App() {
  return (
    <Routes>
      {/* This is the Parent Route. 
        Because it has an element of <MainLayout />, the layout will 
        render, and the specific page below it will render inside its <Outlet /> 
      */}
      <Route element={<MainLayout />}>
        
        {/* Default route redirects to Dashboard */}
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        
        {/* Nested Pages */}
        <Route path="/dashboard" element={
          <Suspense fallback={<LoadingAnimation />}>
            <Dashboard />
          </Suspense>
        } />
        
        <Route path="/projects" element={
          <Suspense fallback={<LoadingAnimation />}>
            <ProjectManager />
          </Suspense>
        } />

        <Route path="/profile" element={
          <Suspense fallback={<LoadingAnimation />}>
            <ProfilePage />
          </Suspense>
        } />

      </Route>

      {/* Catch-all 404 (renders OUTSIDE the layout) */}
      <Route path="*" element={<NotFoundAnimation />} />
    </Routes>
  );
}

export default App;