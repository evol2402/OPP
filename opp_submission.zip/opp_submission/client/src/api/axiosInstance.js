import axios from "axios";

/**
 * Simplified API instance for the Project Management System.
 * Points to the local Express server.
 */
export const api = axios.create({
  baseURL:  "http://localhost:5000/api",
  withCredentials: true,
  timeout: 10000, 
});

/* ---------------- RESPONSE INTERCEPTOR ---------------- */
// A basic interceptor just to handle global error logging
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // If the server is down entirely
    if (!error.response) {
      console.error("Network Error: Check if your backend server is running on port 5000");
    } 
    
    // Log specific server errors (500s, 404s, etc)
    else {
      console.error(
        `API Error [${error.response.status}]:`, 
        error.response.data?.message || error.message
      );
    }

    return Promise.reject(error);
  }
);

export default api;