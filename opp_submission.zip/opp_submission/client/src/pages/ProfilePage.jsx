import React from "react";

const ProfilePage = () => {
  // Hardcoded user data for the assessment
  const user = {
    username: "Admin User",
    bio: "Lead Project Manager overseeing cross-functional development teams and enterprise deployments.",
    role: "Project Manager",
    created_at: "2026-01-15T10:00:00Z",
    bureau: "Technology & Innovation",
    email: "admin.user@example.com"
  };

  // Mock action for the Edit button
  const handleEditClick = () => {
    alert("Edit Profile clicked! (This is a static mock UI for the assessment)");
  };

  return (
    <div className="mx-auto mt-4 sm:mt-10 p-4 sm:p-6 border rounded-2xl shadow-xl bg-white overflow-hidden max-w-6xl">
      
      <div className="bg-gradient-to-br from-emerald-50 via-white to-green-50 flex flex-col items-center justify-center sm:px-6 sm:py-12 rounded-xl">
        <div className="w-full bg-white rounded-2xl shadow-lg border border-gray-100 flex flex-col md:flex-row overflow-hidden">

          {/* Left Section – Profile Avatar & Bio */}
          <div className="md:w-1/2 bg-[linear-gradient(90deg,rgba(85,211,182,1)_0%,rgba(179,220,199,1)_60%,rgba(85,211,182,1)_100%)] text-white p-10 flex flex-col items-center justify-center space-y-6">
            <div className="w-28 h-28 bg-white rounded-full flex items-center justify-center text-4xl font-bold text-emerald-700 shadow-md">
              {user.username.charAt(0).toUpperCase()}
            </div>
            <h2 className="text-3xl font-semibold mt-4 text-black text-center">{user.username}</h2>
            <p className="text-black text-center max-w-sm">{user.bio}</p>
            
            <button
              onClick={handleEditClick}
              className="mt-6 font-semibold py-2 px-6 rounded-lg shadow-md transition bg-dark text-white hover:bg-gray-800"
            >
              Edit Profile
            </button>
          </div>

          {/* Right Section – Account Details */}
          <div className="md:w-1/2 p-8 sm:p-10 flex flex-col justify-center space-y-6">
            
            {/* Replaced TitleBox with native HTML */}
            <div className="w-full mb-2 border-l-4 border-emerald-500 pl-4">
              <h2 className="text-2xl font-black text-gray-900 uppercase">My Profile</h2>
            </div>

            <p className="text-gray-600">  
              Manage your personal information, security preferences, and dashboard access levels.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
              <div className="bg-emerald-50 border border-emerald-100 rounded-lg p-4 text-center">
                <p className="text-gray-700 font-bold text-sm">System Role</p>
                <p className="text-xl font-bold text-emerald-700 mt-1">{user.role}</p>   
              </div>

              <div className="bg-emerald-50 border border-emerald-100 rounded-lg p-4 text-center">
                <p className="text-gray-700 font-bold text-sm">Account Created</p>
                <p className="text-xl font-bold text-emerald-700 mt-1">
                  {new Date(user.created_at).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
              </div>
            </div>

            <div className="mt-8 space-y-3 bg-gray-50 p-4 rounded-lg border border-gray-100">
              <p className="text-gray-500 text-sm flex justify-between">
                <span>Bureau/Department:</span> 
                <span className="font-medium text-gray-800">{user.bureau}</span>
              </p>
              <p className="text-gray-500 text-sm flex justify-between">
                <span>Email Address:</span> 
                <span className="font-medium text-gray-800">{user.email}</span>
              </p>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};

export default ProfilePage;