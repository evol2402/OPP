import React, { useState, useEffect } from 'react';
import { Activity, Briefcase, AlertTriangle, CheckCircle, Database, Calendar, Clock, DollarSign } from 'lucide-react';
import api from '../api/axiosInstance'; 

// Import ALL optimized ECharts components
import ProjectRosePie from '../assets/opp_charts/ProjectRosePie';
import ProjectBarChart from '../assets/opp_charts/ProjectBarChart';
import ProjectLineChart from '../assets/opp_charts/ProjectLineChart'; 


// Import your custom Modal
import Modal from '../components/ui_components/Modal';

// Add these near the top of your Dashboard.jsx
const emeraldStatusPalette = ['#064e3b', '#047857', '#059669', '#10b981', '#34d399']; 
const emeraldPriorityPalette = ['#064e3b', '#059669', '#34d399', '#a7f3d0']; // Critical (Dark) to Low (Light)

// Helper component for the Summary Cards 
const SummaryCard = ({ title, value, icon: Icon, subtitle, onClick }) => (
  <button 
    type="button"
    onClick={onClick}
    className="w-full text-left border border-emerald-300 bg-white p-6 shadow-sm transition-all duration-200 hover:shadow-md hover:border-emerald-500 hover:-translate-y-1 cursor-pointer flex items-center justify-between rounded-xl group"
  >
    <div>
      <h3 className="text-xs font-black uppercase tracking-widest text-emerald-800 mb-1">{title}</h3>
      <p className="text-3xl font-black text-gray-900 group-hover:text-emerald-700 transition-colors">{value}</p>
      <p className="text-xs text-gray-500 mt-1">{subtitle}</p>
    </div>
    <div className="p-4 bg-emerald-50 rounded-full border border-emerald-100 group-hover:bg-emerald-100 transition-colors">
      <Icon size={28} className="text-emerald-600" />
    </div>
  </button>
);

const Dashboard = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [serverError, setServerError] = useState(false);

  // State for KPI Modal
  const [kpiModal, setKpiModal] = useState({ isOpen: false, title: "", projectsList: [] });

  useEffect(() => {
    const fetchRealData = async () => {
      try {
        setLoading(true);
        const res = await api.get("/projects");
        setProjects(res.data);
        setServerError(false);
      } catch (err) {
        console.error("Failed to connect to backend:", err);
        setServerError(true);
      } finally {
        setLoading(false);
      }
    };
    fetchRealData();
  }, []);

  // --- KPI CLICK HANDLER ---
  const handleKpiClick = (title, filterCondition) => {
    setKpiModal({
      isOpen: true,
      title: title,
      projectsList: projects.filter(filterCondition)
    });
  };

  // --- DATA AGGREGATION LOGIC ---

  // 1. Status Data (Rose Pie)
  const statusCounts = projects.reduce((acc, p) => {
    acc[p.status] = (acc[p.status] || 0) + 1;
    return acc;
  }, {});
  const statusChartData = Object.keys(statusCounts).map(name => ({ name, value: statusCounts[name] }));

  // 2. Bureau & Priority Data (Stacked Bar)
  const bureaus = [...new Set(projects.map(p => p.bureau))];
  const priorities = ["Critical", "High", "Medium", "Low"];
  const bureauChartData = {
    categories: bureaus,
    series: priorities.map(pri => ({
      name: pri,
      data: bureaus.map(bur => projects.filter(p => p.bureau === bur && p.priority === pri).length)
    }))
  };


  // 3. Velocity Data (Line Chart - Projects per Month)
  const monthCounts = projects.reduce((acc, p) => {
    if (!p.start_date) return acc;
    const rawMonth = p.start_date.substring(0, 7); 
    const dateObj = new Date(p.start_date);
    const monthLabel = dateObj.toLocaleDateString('default', { month: 'short', year: 'numeric' });

    if (!acc[rawMonth]) acc[rawMonth] = { label: monthLabel, count: 0 };
    acc[rawMonth].count += 1;
    return acc;
  }, {});

  // 4. Upcoming Deadlines (Next 14 Days + Overdue)
  const today = new Date();
  today.setHours(0, 0, 0, 0); // Reset to midnight for accurate day math
  const fourteenDaysFromNow = new Date(today);
  fourteenDaysFromNow.setDate(today.getDate() + 14);

  const deadlineProjects = projects
    .filter(p => {
      if (!p.end_date || p.status === "Completed" || p.status === "Cancelled") return false;
      const endDate = new Date(p.end_date);
      // Keeps overdue projects AND projects due in the next 14 days
      return endDate <= fourteenDaysFromNow; 
    })
    .sort((a, b) => new Date(a.end_date) - new Date(b.end_date)); // Sort nearest first

  const sortedMonthKeys = Object.keys(monthCounts).sort();
  const velocityChartData = {
    labels: sortedMonthKeys.map(key => monthCounts[key].label),
    series: [{
      name: "Projects Initiated",
      data: sortedMonthKeys.map(key => monthCounts[key].count)
    }]
  };

  // 5. Budget Metrics
  const totalBudget = projects.reduce((sum, p) => sum + (Number(p.budget) || 0), 0);
  const activeBudget = projects
    .filter(p => p.status === "In Progress")
    .reduce((sum, p) => sum + (Number(p.budget) || 0), 0);
  const completedBudget = projects
    .filter(p => p.status === "Completed")
    .reduce((sum, p) => sum + (Number(p.budget) || 0), 0);

  // Summary Metrics
  const metrics = {
    total: projects.length,
    active: projects.filter(p => p.status === "In Progress").length,
    critical: projects.filter(p => p.priority === "Critical").length,
    completed: projects.filter(p => p.status === "Completed").length,
  };

  if (loading) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-gray-50">
        <Activity className="text-emerald-500 animate-pulse mb-4" size={48} />
        <p className="text-emerald-700 font-bold tracking-widest uppercase text-sm">Querying Database...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white text-gray-900 p-4 sm:p-8 relative">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* SECTION 1: METRICS (Now Clickable) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <SummaryCard 
            title="Total Projects" 
            value={metrics.total} 
            icon={Briefcase} 
            subtitle="Managed Portfolio" 
            onClick={() => handleKpiClick("All Projects", () => true)} 
          />
          <SummaryCard 
            title="In Progress" 
            value={metrics.active} 
            icon={Activity} 
            subtitle="Currently Active" 
            onClick={() => handleKpiClick("In Progress Projects", (p) => p.status === "In Progress")}
          />
          <SummaryCard 
            title="Critical Risk" 
            value={metrics.critical} 
            icon={AlertTriangle} 
            subtitle="High Priority" 
            onClick={() => handleKpiClick("Critical Priority Projects", (p) => p.priority === "Critical")}
          />
          <SummaryCard 
            title="Delivered" 
            value={metrics.completed} 
            icon={CheckCircle} 
            subtitle="Verified Completed" 
            onClick={() => handleKpiClick("Completed Projects", (p) => p.status === "Completed")}
          />
        </div>

        {/* SECTION 2: DISTRIBUTION CHARTS (Pie & Bar) */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="border border-gray-200 bg-white p-6 rounded-2xl shadow-sm min-h-[450px]">
             <ProjectRosePie data={statusChartData} title="PORTFOLIO STATUS" subtext="Current projects by lifecycle stage" colors={emeraldStatusPalette}  />
          </div>
          <div className="border border-gray-200 bg-white p-6 rounded-2xl shadow-sm min-h-[450px]">
            <ProjectLineChart chartData={velocityChartData} title="MONTHLY VELOCITY" subtext="New projects initiated per month" showArea={true} colors={emeraldPriorityPalette} />
      
          </div>
        </div>

        {/* SECTION 3: DEADLINES & FINANCIALS */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Side: Upcoming Deadlines (Takes up 2 columns) */}
          <div className="lg:col-span-2 h-full">
            {serverError ? (
              <div className="bg-[#4a0404] border-red-500 p-8 rounded-2xl shadow-lg flex flex-col items-center justify-center text-center h-full border">
                <Database className="text-red-400 mb-4" size={48} />
                <p className="text-white font-black text-xl tracking-widest uppercase">System Offline</p>
                <p className="text-red-200 text-sm mt-2 font-medium">SQLite DB Disconnected</p>
              </div>
            ) : (
              <div className="border border-gray-200 bg-white rounded-2xl shadow-sm h-full flex flex-col overflow-hidden min-h-[350px]">
                <div className="bg-amber-50 px-6 py-4 border-b border-amber-100 flex justify-between items-center shrink-0">
                  <h3 className="text-xs font-black uppercase tracking-widest text-amber-800">Upcoming Deadlines</h3>
                  <Calendar size={16} className="text-amber-600" />
                </div>
                
                <div className="p-4 flex-1 flex flex-col overflow-hidden">
                  {deadlineProjects.length > 0 ? (
                    <>
                      <ul className="divide-y divide-gray-100 flex-1 overflow-y-auto pr-2">
                        {deadlineProjects.slice(0, 4).map(p => {
                          const endDate = new Date(p.end_date);
                          const isOverdue = endDate < today;
                          const daysLeft = Math.ceil((endDate - today) / (1000 * 60 * 60 * 24));

                          return (
                            <li key={p.id} className="py-3 flex justify-between items-start gap-2 group cursor-default">
                              <div className="truncate pr-2">
                                <p className="text-sm font-bold text-gray-900 truncate group-hover:text-amber-700 transition-colors">{p.project_name}</p>
                                <div className="flex items-center gap-1 mt-0.5">
                                  <Clock size={12} className={isOverdue ? "text-red-500" : "text-amber-500"} />
                                  <p className={`text-xs font-semibold ${isOverdue ? "text-red-600" : "text-amber-600"}`}>
                                    {isOverdue ? "Overdue" : daysLeft === 0 ? "Due Today" : `Due in ${daysLeft} days`}
                                  </p>
                                </div>
                              </div>
                              <span className={`shrink-0 px-2 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter ${
                                p.status === 'In Progress' ? 'bg-blue-100 text-blue-800' :
                                p.status === 'On Hold' ? 'bg-orange-100 text-orange-800' :   
                                p.status === 'Planning' ? 'bg-slate-100 text-slate-800' : 
                                p.status === 'New' ? 'bg-purple-100 text-purple-800' : 
                                'bg-gray-100 text-gray-800'
                              }`}>
                                {p.status}
                              </span>
                            </li>
                          );
                        })}
                      </ul>
                      
                      {deadlineProjects.length > 4 && (
                        <div className="pt-3 mt-auto border-t border-gray-100">
                          <button 
                            onClick={() => handleKpiClick("Upcoming Deadlines", (p) => {
                                if (!p.end_date || p.status === "Completed" || p.status === "Cancelled") return false;
                                return new Date(p.end_date) <= fourteenDaysFromNow;
                            })}
                            className="w-full py-2 text-xs font-bold text-amber-700 bg-amber-50 hover:bg-amber-100 rounded-lg transition-colors"
                          >
                            View All Deadlines ({deadlineProjects.length})
                          </button>
                        </div>
                      )}
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-center py-8">
                      <CheckCircle size={32} className="text-emerald-400 mb-3" />
                      <p className="text-sm font-bold text-gray-800">No Imminent Deadlines</p>
                      <p className="text-xs text-gray-500 mt-1">Your next 14 days are clear.</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Right Side: Financial Overview (Takes up 1 column) */}
          <div className="lg:col-span-1 h-full">
            <div className="border border-gray-200 bg-white rounded-2xl shadow-sm h-full flex flex-col overflow-hidden min-h-[350px]">
              <div className="bg-emerald-50 px-6 py-4 border-b border-emerald-100 flex justify-between items-center shrink-0">
                <h3 className="text-xs font-black uppercase tracking-widest text-emerald-800">Financial Overview</h3>
                <DollarSign size={16} className="text-emerald-600" />
              </div>
              <div className="p-6 flex-1 flex flex-col justify-center">
                <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Total Portfolio Budget</p>
                <p className="text-4xl font-black text-gray-900 mt-2">${totalBudget.toLocaleString()}</p>

                <div className="mt-10 space-y-6">
                  {/* Active Allocation Bar */}
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600 font-semibold">Active Allocation</span>
                      <span className="font-bold text-blue-600">${activeBudget.toLocaleString()}</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2.5 shadow-inner">
                      <div 
                        className="bg-blue-500 h-2.5 rounded-full transition-all duration-1000" 
                        style={{ width: `${totalBudget > 0 ? (activeBudget / totalBudget) * 100 : 0}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Completed Value Bar */}
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600 font-semibold">Delivered Value</span>
                      <span className="font-bold text-emerald-600">${completedBudget.toLocaleString()}</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2.5 shadow-inner">
                      <div 
                        className="bg-emerald-500 h-2.5 rounded-full transition-all duration-1000" 
                        style={{ width: `${totalBudget > 0 ? (completedBudget / totalBudget) * 100 : 0}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
        </div>

        {/* SECTION 4: FULL WIDTH TRAJECTORY */}
        <div className="border border-gray-200 bg-white p-6 rounded-2xl shadow-sm w-full">
               <ProjectBarChart chartData={bureauChartData} title="BUREAU ALLOCATION" subtext="Resource load by department and priority" stacked={true} colors={emeraldPriorityPalette} />
      
        </div>

      </div>

      
 {/* KPI LIST MODAL */}
      {kpiModal.isOpen && (
        <Modal
          onClose={() => setKpiModal({ isOpen: false, title: "", projectsList: [] })}
          showCancel={true}
          cancelLabel="Close"
          widthClassName="max-w-2xl"
        >
          <div className="p-2">
            <h3 className="text-xl font-black text-gray-900 mb-4 uppercase tracking-tight">{kpiModal.title}</h3>
            
            {kpiModal.projectsList.length > 0 ? (
              <ul className="divide-y divide-gray-100 max-h-96 overflow-y-auto pr-2">
                {kpiModal.projectsList.map((p) => (
                  <li key={p.id} className="py-3 flex justify-between items-start group hover:bg-gray-50 px-2 rounded-lg transition-colors">
                    
                    {/* LEFT SIDE: Text Content */}
                    <div className="flex-1 pr-4">
                      <p className="font-bold text-gray-800 text-sm">{p.project_name}</p>
                      
                      {/* Truncated Description */}
                      {p.description && (
                        <p className="text-xs text-gray-600 mt-1 line-clamp-2 leading-relaxed">
                          {p.description}
                        </p>
                      )}
                      
                      <p className="text-[10px] text-gray-400 mt-1 font-medium uppercase tracking-wider">{p.bureau}</p>
                    </div>

                    {/* RIGHT SIDE: Status Badge */}
                    <div className="text-right shrink-0 mt-0.5">
                      <span className={`px-2 py-1 rounded-full text-[10px] uppercase font-black tracking-tighter ${
                        p.status === 'Completed' ? 'bg-green-100 text-green-800' :
                        p.status === 'In Progress' ? 'bg-blue-100 text-blue-800' :
                        p.status === 'On Hold' ? 'bg-amber-100 text-amber-800' :   
                        p.status === 'Cancelled' ? 'bg-red-100 text-red-800' :
                        p.status === 'Planning' ? 'bg-slate-100 text-slate-800' : 
                        p.status === 'New' ? 'bg-purple-100 text-purple-800' : 
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {p.status}
                      </span>
                    </div>
                    
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-gray-500 text-sm italic py-4 text-center">No projects found for this category.</p>
            )}
          </div>
        </Modal>
      )}

    </div>
  );
};

export default Dashboard;