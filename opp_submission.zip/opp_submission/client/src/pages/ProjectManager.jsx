import React, { useState, useEffect } from "react";
import api from "../api/axiosInstance";
import {
  Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper,
  Dialog, DialogTitle, DialogContent, DialogActions, TextField, MenuItem, Button
} from "@mui/material";
import { ArrowLeft, Plus, Edit, Trash2, AlertTriangle, Lock, Unlock, Filter } from "lucide-react";
import { useNavigate } from "react-router-dom";

// Custom UI Components
import TitleBox from "../components/ui_components/TitleBox";
import ActionButton from "../components/ui_components/ActionButton";
import MessageBox from "../components/ui_components/MessageBox";
import Modal from "../components/ui_components/Modal";
import LoadingAnimation from "../components/animation_components/LoadingAnimation";

const STATUS_OPTIONS = ["New", "Planning", "In Progress", "On Hold", "Completed", "Cancelled"];
const PRIORITY_OPTIONS = ["Low", "Medium", "High", "Critical"];

// --- UPDATED: Added budget to initial state ---
const initialFormState = {
  project_name: "", bureau: "", status: "Planning",
  priority: "Medium", start_date: "", end_date: "", description: "", budget: 0
};

export default function ProjectManager() {
  const navigate = useNavigate();

  // --- STATE ---
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Notification State
  const [message, setMessage] = useState({ text: "", type: "success" });

  // Form/Edit Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [formData, setFormData] = useState(initialFormState);
  const [isEditing, setIsEditing] = useState(false);
  const [errors, setErrors] = useState({});

  // Delete Confirmation State
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [projectToDelete, setProjectToDelete] = useState(null);

  // Table Control States
  const [isEditMode, setIsEditMode] = useState(false);
  const [filters, setFilters] = useState({ status: "All", bureau: "All", priority: "All" });

  // --- HELPERS ---
  const showNotification = (text, type = "success") => {
    setMessage({ text, type });
  };

  // --- DERIVED DATA (For Slicers & Table) ---
  const uniqueBureaus = ["All", ...new Set(projects.map(p => p.bureau).filter(Boolean))];

  const filteredProjects = projects.filter((p) => {
    const matchStatus = filters.status === "All" || p.status === filters.status;
    const matchBureau = filters.bureau === "All" || p.bureau === filters.bureau;
    const matchPriority = filters.priority === "All" || p.priority === filters.priority;
    return matchStatus && matchBureau && matchPriority;
  });

  const handleFilterChange = (e) => {
    setFilters(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  // --- API ACTIONS ---
  useEffect(() => {
    const fetchProjects = async () => {
      try {
        setLoading(true);
        const res = await api.get("/projects");
        setProjects(res.data);
      } catch (err) {
        showNotification("Could not load projects from server.", "error");
      } finally {
        setLoading(false);
      }
    };
    fetchProjects();
  }, []);

  const handleSave = async () => {
    if (!validateForm()) return;
    try {
      if (isEditing) {
        await api.put(`/projects/${formData.id}`, formData);
        setProjects(projects.map(p => p.id === formData.id ? formData : p));
        showNotification("Project updated successfully!", "success");
      } else {
        const res = await api.post("/projects", formData);
        setProjects([res.data, ...projects]); // Added to top of list
        showNotification("New project created!", "success");
      }
      handleCloseModal();
    } catch (err) {
      showNotification("Error saving project changes.", "error");
    }
  };

  const triggerDeleteModal = (project) => {
    setProjectToDelete(project);
    setDeleteModalOpen(true);
  };

  const handleConfirmDelete = async () => {
    try {
      await api.delete(`/projects/${projectToDelete.id}`);
      setProjects(projects.filter(p => p.id !== projectToDelete.id));
      showNotification(`Project "${projectToDelete.project_name}" removed.`, "info");
    } catch (err) {
      showNotification("Failed to delete project.", "error");
    } finally {
      setDeleteModalOpen(false);
      setProjectToDelete(null);
    }
  };

  // --- FORM LOGIC ---
  const handleOpenModal = (project = null) => {
    setErrors({});
    if (project) {
      setFormData(project);
      setIsEditing(true);
    } else {
      setFormData(initialFormState);
      setIsEditing(false);
    }
    setModalOpen(true);
  };

  const handleCloseModal = () => setModalOpen(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: null }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.project_name.trim()) newErrors.project_name = "Project name is required";
    if (!formData.bureau.trim()) newErrors.bureau = "Bureau is required";
    if (!formData.start_date) newErrors.start_date = "Start date is required";
    if (formData.start_date && formData.end_date && formData.end_date < formData.start_date) {
        newErrors.end_date = "End date cannot be before start date";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // --- UPDATED: Added Budget to Headers ---
  const tableHeaders = ["Name", "Bureau", "Budget", "Status", "Priority", "Timeline"];
  if (isEditMode) tableHeaders.push("Actions");

  return (
    <div className="p-4 sm:p-6 md:p-8 relative">
      
      {/* Notifications Area */}
      <MessageBox 
        boxMessage={message.text} 
        type={message.type} 
        onClose={() => setMessage({ text: "", type: "success" })}
        duration={3000} 
      />

      {/* Top Bar */}
      <div className="flex items-center justify-between mb-5">
        <ActionButton
          tooltip="Go to Dashboard"
          label={<ArrowLeft />}
          onClick={() => navigate("/dashboard")}
        />
        <ActionButton
          label={
            <div className="flex items-center gap-2 text-white">
              <Plus size={18} />
              <span className="font-semibold">New Project</span>
            </div>
          }
          tooltip="Create a new project record"
          onClick={() => handleOpenModal()}
        />
      </div>

      {/* Header */}
      <div className="mb-6">
        <TitleBox className="w-full" title="Project Portfolio Management">
           <div className="mt-2 text-sm text-gray-600 space-y-2">
             <p>Create, update, and manage the status of all active and planned projects.</p>
           </div>
        </TitleBox>
      </div>

      {/* Slicers & Edit Toggle Toolbar */}
      <div className="flex flex-col md:flex-row justify-between items-end mb-4 gap-4 bg-gray-50 p-3 rounded-xl border border-gray-200">
        <div className="flex items-center gap-2 text-gray-600 font-semibold text-sm">
          <Filter size={18} />
          <span>Filters</span>
        </div>
        
        <div className="flex flex-wrap items-center justify-end gap-3 w-full md:w-auto">
          {/* Bureau Slicer */}
          <TextField select size="small" name="bureau" value={filters.bureau} onChange={handleFilterChange} label="Bureau" className="w-72 bg-white" InputLabelProps={{ shrink: true }}>
            {uniqueBureaus.map(b => <MenuItem key={b} value={b}>{b}</MenuItem>)}
          </TextField>
          
          {/* Status Slicer */}
          <TextField select size="small" name="status" value={filters.status} onChange={handleFilterChange} label="Status" className="w-36 bg-white" InputLabelProps={{ shrink: true }}>
            <MenuItem value="All">All</MenuItem>
            {STATUS_OPTIONS.map(opt => <MenuItem key={opt} value={opt}>{opt}</MenuItem>)}
          </TextField>

          {/* Priority Slicer */}
          <TextField select size="small" name="priority" value={filters.priority} onChange={handleFilterChange} label="Priority" className="w-32 bg-white" InputLabelProps={{ shrink: true }}>
            <MenuItem value="All">All</MenuItem>
            {PRIORITY_OPTIONS.map(opt => <MenuItem key={opt} value={opt}>{opt}</MenuItem>)}
          </TextField>

          <div className="w-px h-8 bg-gray-300 mx-2 hidden md:block"></div>

          {/* Enable Editing Toggle */}
          <button 
            onClick={() => setIsEditMode(!isEditMode)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-sm transition-colors duration-200 ${
              isEditMode 
                ? "bg-rose-100 text-rose-700 border border-rose-300 hover:bg-rose-200" 
                : "bg-white text-gray-600 border border-gray-300 hover:bg-gray-100"
            }`}
          >
            {isEditMode ? <Unlock size={16} /> : <Lock size={16} />}
            {isEditMode ? "Editing Enabled" : "Enable Editing"}
          </button>
        </div>
      </div>

      {/* Main Table */}
      <div className="overflow-x-auto relative">
        {loading ? (
          <LoadingAnimation />
        ) : (
          <TableContainer component={Paper} className="shadow-sm border border-gray-300">
            <Table sx={{ minWidth: 850 }}>
              <TableHead className="bg-gray-100">
                <TableRow>
                  {tableHeaders.map((col) => (
                    <TableCell key={col} className="font-bold text-gray-700 bg-gray-100 uppercase text-xs">
                      {col}
                    </TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredProjects.length > 0 ? (
                  filteredProjects.map((row) => (
                    <TableRow key={row.id} className="hover:bg-gray-50 transition-colors">
                      <TableCell className="font-medium text-gray-900">{row.project_name}</TableCell>
                      <TableCell>{row.bureau}</TableCell>
                      
                      {/* --- UPDATED: Budget Display Cell --- */}
                      <TableCell className="font-mono text-gray-600">
                        ${Number(row.budget || 0).toLocaleString()}
                      </TableCell>

                      <TableCell>
                        <span className={`px-2 py-1 rounded-full text-[10px] uppercase font-black tracking-tighter ${
                         row.status === 'Completed' ? 'bg-green-100 text-green-800' :
                         row.status === 'In Progress' ? 'bg-blue-100 text-blue-800' :
                         row.status === 'On Hold' ? 'bg-amber-100 text-amber-800' :   
                         row.status === 'Cancelled' ? 'bg-red-100 text-red-800' :
                         row.status === 'Planning' ? 'bg-slate-100 text-slate-800' : 
                         row.status === 'New' ? 'bg-purple-100 text-purple-800' : 
                         'bg-gray-100 text-gray-800'
                        }`}>
                            {row.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm font-semibold">{row.priority}</TableCell>
                      <TableCell className="text-[11px] text-gray-500 font-mono">
                         {row.start_date} <span className="text-gray-300 mx-1">→</span> {row.end_date || "TBD"}
                      </TableCell>
                      
                      {isEditMode && (
                        <TableCell>
                          <div className="flex gap-1 animate-in fade-in duration-300">
                            <button onClick={() => handleOpenModal(row)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-full transition-colors">
                              <Edit size={16} />
                            </button>
                            <button onClick={() => triggerDeleteModal(row)} className="p-2 text-red-600 hover:bg-red-50 rounded-full transition-colors">
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={isEditMode ? 7 : 6} align="center" className="py-20 text-gray-400 italic">
                      {projects.length === 0 ? "No projects currently stored in SQLite database." : "No projects match the selected filters."}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </div>

      {/* --- MODALS --- */}

      {/* 1. Edit/Create Dialog (MUI) */}
      <Dialog open={modalOpen} onClose={handleCloseModal} maxWidth="md" fullWidth>
        <DialogTitle className="font-black uppercase text-gray-800 tracking-tight">
          {isEditing ? "Modify Project Record" : "Register New Project"}
        </DialogTitle>
        <DialogContent dividers className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <TextField name="project_name" label="Project Name" value={formData.project_name} onChange={handleChange}
            error={!!errors.project_name} helperText={errors.project_name} fullWidth size="small" className="md:col-span-2" />
          
          <TextField name="bureau" label="Bureau" value={formData.bureau} onChange={handleChange}
            error={!!errors.bureau} helperText={errors.bureau} fullWidth size="small" />
            
          {/* ---  Budget Input Field --- */}
          <TextField name="budget" label="Budget Allocation ($)" type="number" value={formData.budget} onChange={handleChange}
            fullWidth size="small" />

          <TextField select name="status" label="Status" value={formData.status} onChange={handleChange} fullWidth size="small">
            {STATUS_OPTIONS.map(opt => <MenuItem key={opt} value={opt}>{opt}</MenuItem>)}
          </TextField>
          <TextField select name="priority" label="Priority" value={formData.priority} onChange={handleChange} fullWidth size="small">
            {PRIORITY_OPTIONS.map(opt => <MenuItem key={opt} value={opt}>{opt}</MenuItem>)}
          </TextField>
          <div className="md:col-span-2 grid grid-cols-2 gap-4">
            <TextField type="date" name="start_date" label="Start Date" value={formData.start_date} onChange={handleChange}
              error={!!errors.start_date} helperText={errors.start_date} InputLabelProps={{ shrink: true }} fullWidth size="small" />
            <TextField type="date" name="end_date" label="End Date" value={formData.end_date} onChange={handleChange}
              error={!!errors.end_date} helperText={errors.end_date} InputLabelProps={{ shrink: true }} fullWidth size="small" />
          </div>
          <TextField name="description" label="Project Description" value={formData.description} onChange={handleChange}
            multiline rows={3} fullWidth size="small" className="md:col-span-2" />
        </DialogContent>
        <DialogActions className="p-4 bg-gray-50">
          <Button onClick={handleCloseModal} color="inherit">Discard</Button>
          <Button onClick={handleSave} variant="contained" className="bg-emerald-600 hover:bg-emerald-700 shadow-none px-6">
            {isEditing ? "Update Entry" : "Save to Database"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* 2. Delete Confirmation (Custom Modal) */}
      {deleteModalOpen && (
        <Modal
          onClose={() => setDeleteModalOpen(false)}
          showCancel={true}
          cancelLabel="Keep Record"
          showAction={true}
          actionLabel="Remove Permanently"
          onAction={handleConfirmDelete}
          actionClassName="bg-dark text-white hover:bg-gray-700 transition-colors duration-200"
        >
          <div className="text-center py-2">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-rose-50 mb-4">
              <AlertTriangle className="h-6 w-6 text-rose-600" />
            </div>
            <h3 className="text-xl font-black text-gray-900 mb-2 uppercase tracking-tighter">Confirm Deletion</h3>
            <p className="text-sm text-gray-500 leading-relaxed">
              Are you sure you want to delete <span className="font-bold text-gray-800">{projectToDelete?.project_name}</span>? 
              This action will permanently wipe the record from the <strong>projects.db</strong> file.
            </p>
          </div>
        </Modal>
      )}

    </div>
  );
}