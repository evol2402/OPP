import React, { Suspense } from "react";
import { Outlet } from "react-router-dom";

// UI Components
import Header from "../ui_components/Header";
import LeftBar from "../ui_components/LeftBar";
import Footer from "../ui_components/Footer";
import ScrollToTop from "../ui_components/ScrollToTop";
import LoadingAnimation from "../animation_components/LoadingAnimation";

const MainLayout = () => {
  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Top Navigation */}
      <Header />

      <div className="flex flex-1 overflow-hidden relative">
        {/* Sidebar Navigation */}
        <LeftBar />

        {/* Main Content Container */}
        <main 
          className="relative flex-1 flex flex-col overflow-y-auto bg-white ml-0 sm:ml-20 mt-1 mr-1 mb-0 shadow-sm rounded-tl-md" 
          id="main-content"
        >
          {/* Content Wrapper: Expands to push footer down */}
          <div className="flex-1 p-4 sm:p-6">
            <Suspense fallback={<LoadingAnimation />}>
              <Outlet />
            </Suspense>
          </div>

          {/* Footer */}
          <Footer version="1.0.0">
            <span className="text-sm text-gray-500 font-medium">
              Project Management System - Assessment
            </span>
          </Footer>

          <ScrollToTop containerId="main-content" />
        </main>
      </div>
    </div>
  );
};

export default MainLayout;