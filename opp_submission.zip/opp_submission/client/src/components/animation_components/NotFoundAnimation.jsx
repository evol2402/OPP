import Lottie from "lottie-react";
import dashboardAnimation from "../../assets/Lotties/not_found.json";
import React from "react";

const NotFoundAnimation = () => {
  return (
    <div className="flex flex-col items-center justify-center w-full h-screen bg-white p-6 text-center">
      <div role="img" aria-label="Not Found Animation" className="w-full max-w-md">
        <Lottie animationData={dashboardAnimation} loop={true} />
      </div>

      <div className="mt-6 text-lg text-gray-800 font-semibold">404 — Page not found</div>
    
      <p className="mt-4 text-sm text-gray-500">
        Please check the URL or use the navigation to find your way.
      </p>
    </div>
  );
};

export default NotFoundAnimation;