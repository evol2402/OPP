import Lottie from "lottie-react";
import lottie from "lottie-web/build/player/lottie_light"; // light build, avoids eval
import dashboardAnimation from "../../assets/Lotties/loading.json"; // make sure the path is correct
import React from "react";

const LoadingAnimation = () => {
  return (
    <div 
    role="img"
    aria-label="Loading Animation"
     className="flex items-center justify-center w-full h-screen ">
      <div className="w-24 h-24 sm:w-32 sm:h-32 md:w-40 md:h-40">
        <Lottie lottie={lottie} animationData={dashboardAnimation} loop={true} />
      </div>
    </div>
  );
};

export default LoadingAnimation;
// LoadingAnimation (Lottie)
// Centered spinner-like animation used during data fetch/loading states.
