import React from "react";
import { Link } from "react-router-dom";
import { User } from "lucide-react";
import MobileSidebar from "../ui_components/mobile_components/MobileSidebar";
import { useViewportSize } from "@mantine/hooks";
import opp from '../../assets/images/opp.png';

export default function Header() {
  const { width } = useViewportSize();
  const isMobile = width < 640;

  // Hardcoded profile data for the assessment
  const mockUser = {
    name: "Admin User",
    role: "Project Manager"
  };

  return (
    <header className="flex w-full h-24 z-50 border-b shadow-lg shadow-gray-800/50">
      
      {/* Left: Brand/Logo */}
      <div className="w-1/4 sm:w-64 bg-[linear-gradient(90deg,rgba(85,211,182,1)_0%,rgba(179,220,199,1)_60%,rgba(85,211,182,1)_100%)] flex items-center justify-center p-2 border-r border-emerald-300">
        <img
          src={opp}
          alt="OPP Logo"
          loading="eager"
          className="h-16 sm:h-20 w-auto object-contain"
        />
      </div>

      {/* Right: Unified Single Row */}
      <div className="flex-1 flex items-center justify-between px-4 sm:px-8 bg-[linear-gradient(90deg,rgba(57,72,87,1)_0%,rgba(141,154,179,1)_100%)]">
        
        {/* Page Title */}
        <span className="font-heading text-white text-lg sm:text-xl md:text-2xl lg:text-3xl font-bold tracking-wide">
          Project Management Dashboard
        </span>
        
        {/* Actions Area */}
<div className="flex items-center gap-4">
  {!isMobile ? (
    /* Desktop: Circular Initial Avatar */
    <Link 
      to="/profile" 
      className="transition-all duration-200 transform hover:scale-105 active:scale-95"
      title={mockUser.name} // Native tooltip showing the full username
    >
      <div className="
        flex items-center justify-center 
        w-10 h-10 
        rounded-full 
        bg-dark hover:bg-[#de454a] 
        text-white font-bold text-lg
        border border-white/20
        shadow-md
        transition-colors
      ">
        {/* Grabs the first letter of the name and makes it uppercase */}
        {mockUser.name?.charAt(0).toUpperCase()}
      </div>
    </Link>
  ) : (
    /* Mobile: Sidebar Trigger */
    <MobileSidebar />
  )}
</div>

      </div>
    </header>
  );
}