// Scroll-to-top FAB for a scrollable container (by id).
// - Listens to the container's scroll event and appears after 300px
import React, { useState, useEffect } from "react";
import { ChevronUp } from "lucide-react";
import PropTypes from "prop-types"; // ✅ import PropTypes

const ScrollToTop = ({ containerId }) => {
  const [visible, setVisible] = useState(false);

  const toggleVisibility = () => {
    const container = document.getElementById(containerId);
    if (container && container.scrollTop > 300) {
      setVisible(true);
    } else {
      setVisible(false);
    }
  };

  const scrollToTop = () => {
    const container = document.getElementById(containerId);
    if (container) {
      container.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    }
  };

  useEffect(() => {
    const container = document.getElementById(containerId);
    if (container) {
      container.addEventListener("scroll", toggleVisibility);
      return () => {return container.removeEventListener("scroll", toggleVisibility)};
    }
  }, [containerId]);

  return (
    visible && (
      <button
  onClick={scrollToTop}
  className="
    fixed bottom-6 right-4
    px-3 py-2 z-30 
    rounded-full bg-red-600 text-white 
    shadow-lg hover:bg-red-700 
    transition duration-300 
    flex items-center gap-2
  "
  aria-label="Scroll to top"
>
  <ChevronUp className="w-5 h-5" />
  <span className="text-sm font-semibold">TOP</span>
</button>

    )
  );
};
ScrollToTop.propTypes = {
  containerId: PropTypes.string, // optional string ID of the scroll container
};

export default ScrollToTop;
