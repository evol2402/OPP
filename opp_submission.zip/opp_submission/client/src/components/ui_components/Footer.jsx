import React from "react";

export default function Footer({
  year = new Date().getFullYear(),
  version = "1.0.0",
  children
}) {
  return (
    <footer
      role="contentinfo"
      className="w-full bg-white text-gray-600 text-sm py-4 px-6 flex flex-col sm:flex-row items-center justify-between border-t border-gray-200"
    >
      {/* Left Section: Copyright & Version */}
      <div className="flex items-center gap-2 mb-2 sm:mb-0">
        <span>
          &copy; {year} Project Management System
        </span>
        {version && (
          <span className="text-gray-400">
            | v{version}
          </span>
        )}
      </div>

      {/* Right Section: Custom injected text (from MainLayout) */}
      {children && (
        <div className="font-medium text-gray-500">
          {children}
        </div>
      )}
    </footer>
  );
}