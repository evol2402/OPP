import React from "react";
import PropTypes from "prop-types";
import { X } from "lucide-react"; // Import the icon

export default function Modal({
  children,
  onClose,
  showCancel = false,
  cancelLabel = "Cancel",
  blurBackground = true,
  widthClassName = "max-w-md",
  bodyClassName = "",

  showAction = false,
  actionLabel = "Save",
  onAction,
  actionClassName = "bg-gray-900 text-white", // Changed bg-dark to standard Tailwind if needed
}) {
  return (
    <div
      className={`fixed inset-0 z-[50] flex items-center justify-center p-4 sm:p-6 overflow-y-auto ${blurBackground ? "backdrop-blur-sm" : ""}`}
      style={{ isolation: "isolate" }}
    >
      <div
        className={`bg-white shadow-2xl w-full ${widthClassName} animate-fade-in max-h-[90vh] flex flex-col`} // Removed rounded-2xl, changed bg to white for better contrast
      >
        {/* Content */}
        <div className={`flex-1 overflow-y-auto p-6 text-gray-800 ${bodyClassName}`}>
          {children}
        </div>

        {/* Action Buttons */}
        {(showCancel || showAction) && (
          <div
            className="
              flex flex-col sm:flex-row
              justify-end gap-3
              p-4 sm:p-5
              border-t border-gray-100
              bg-gray-50
            "
          >
           {showCancel && (
  <button
    onClick={onClose}
    className="
      flex items-center justify-center
      w-full sm:w-auto
      bg-gray-300 hover:bg-gray-200 
      text-gray-700 font-semibold
      py-2.5 px-5
      transition-colors
      duration-200
      rounded-none
    " 
  >
    <X size={16} className="mr-2" />
    {cancelLabel}
  </button>
)}

            {showAction && (
              <button
                onClick={onAction}
                className={`
                  w-full sm:w-auto
                  ${actionClassName}
                  font-semibold
                  py-2.5 px-5
                  transition-colors
                  duration-200
                  rounded-none
                `} // Removed rounded-xl
              >
                {actionLabel}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

Modal.propTypes = {
  children: PropTypes.node.isRequired,
  onClose: PropTypes.func.isRequired,

  showCancel: PropTypes.bool,
  cancelLabel: PropTypes.string,
  blurBackground: PropTypes.bool,
  widthClassName: PropTypes.string,
  bodyClassName: PropTypes.string,

  showAction: PropTypes.bool,
  actionLabel: PropTypes.string,
  onAction: PropTypes.func,
  actionClassName: PropTypes.string,
};