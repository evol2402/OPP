import React, { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { 
  MenuIcon, 
  XIcon, 
  User, 
  LayoutDashboard, 
  FolderKanban, 
  Info, 
  Keyboard 
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// Hardcoded menu items exactly like the LeftBar
const menuItems = [
  { icon: <LayoutDashboard size={20} />, text: "Dashboard", path: "/dashboard" },
  { icon: <FolderKanban size={20} />, text: "Projects", path: "/projects" },
];

const MobileSidebar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false);
  
  const navigate = useNavigate();

  // Drawer open/close controls
  const toggleSidebar = () => setIsOpen(!isOpen);
  const closeSidebar = () => setIsOpen(false);

  return (
    <>
      {/* Toggle button visible on mobile viewports */}
      <button
        aria-label="Toggle Sidebar"
        className="
          md:hidden 
          p-2 
          z-50 
          bg-dark 
          rounded-lg 
          transition-all duration-200 ease-in-out
          hover:scale-105 hover:shadow-lg hover:bg-dark/90
          active:scale-95 active:shadow-inner
        "
        onClick={toggleSidebar}
      >
        {isOpen ? (
          <XIcon className="w-6 h-6 text-white transition-transform duration-200" />
        ) : (
          <MenuIcon className="w-6 h-6 text-white transition-transform duration-200" />
        )}
      </button>

      {/* Sidebar overlay: dims background and closes drawer on click */}
      <div
        role="button"
        tabIndex={0}
        aria-label="Close Sidebar Overlay"
        className={`fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity duration-300 ${
          isOpen ? "opacity-100 visible" : "opacity-0 invisible pointer-events-none"
        }`}
        onClick={closeSidebar}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") closeSidebar();
        }}
      />

      {/* Drawer panel (Slides up from bottom) */}
      <aside
        className={`fixed inset-0 w-full bg-sidebar z-50 transform transition-transform duration-300 flex flex-col ${
          isOpen ? "translate-y-0" : "translate-y-full"
        }`}
      >
        <div className="flex flex-col p-6 relative h-full min-h-0">
          
          {/* Header & Close button */}
          <div className="flex items-center justify-between border-b border-white/20 pb-4">
            <span className="text-white font-bold text-xl tracking-wide">Menu</span>
            <button
              aria-label="Close Sidebar"
              className="p-2 bg-white rounded-full shadow transition-all duration-200 ease-in-out hover:bg-gray-200 hover:scale-105 hover:shadow-md active:scale-95 active:shadow-inner"
              onClick={closeSidebar}
            >
              <XIcon className="w-5 h-5 text-black transition-transform duration-200" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="flex-1 flex flex-col gap-3 overflow-auto mt-6">
            {menuItems.map((link) => (
              <NavLink
                key={link.text}
                to={link.path}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-4 py-3 rounded-lg cursor-pointer transition-colors duration-200 ${
                    isActive
                      ? "text-white font-semibold bg-dark shadow-md"
                      : "text-gray-300 hover:text-white hover:bg-dark/50"
                  }`
                }
                onClick={closeSidebar}
              >
                {link.icon} 
                <span className="text-lg">{link.text}</span>
              </NavLink>
            ))}
          </nav>

          {/* Bottom section: Info Button & Profile */}
          <div className="mt-auto pt-4 border-t border-white/20 flex flex-col gap-3 shrink-0">
            
            {/* System Info Button */}
            <button
              onClick={() => setIsInfoModalOpen(true)}
              className="flex items-center gap-3 px-4 py-3 rounded-lg w-full text-left cursor-pointer transition-colors duration-200 text-emerald-100 bg-white/5 hover:text-white hover:bg-white/10"
            >
              <Info size={20} />
              <span className="text-lg font-medium">System Info</span>
            </button>

            {/* Profile Button */}
            <button
              className="flex items-center gap-4 bg-white/10 p-3 rounded-lg shadow-inner hover:bg-white/20 transition-colors w-full text-left"
              onClick={() => {
                closeSidebar();
                navigate("/profile");
              }}
            >
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-emerald-700 shadow-md shrink-0">
                <User size={24} />
              </div>
              <div className="flex flex-col text-white">
                <span className="font-bold text-sm">Admin User</span>
                <span className="text-xs text-gray-300">View Profile</span>
              </div>
            </button>
          </div>
          
        </div>
      </aside>

      {/* Info Modal (Mirrors LeftBar) */}
      <AnimatePresence>
        {isInfoModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col"
            >
              {/* Modal Header */}
              <div className="bg-gray-50 px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                <div className="flex items-center gap-2 text-gray-800 font-black uppercase tracking-tight">
                  <Keyboard size={20} className="text-emerald-600" />
                  System Info & Shortcuts
                </div>
              </div>

              {/* Modal Body */}
              <div className="p-6 space-y-6">
                <p className="text-sm text-gray-600 leading-relaxed">
                  Navigate the desktop dashboard more efficiently using these built-in keyboard shortcuts.
                </p>

                <div className="space-y-3">
                  <div className="flex justify-between items-center py-2 border-b border-gray-100">
                    <span className="text-sm font-semibold text-gray-700">Toggle Sidebar (Desktop)</span>
                    <div className="flex gap-1">
                      <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs font-mono font-bold shadow-sm text-gray-600">Ctrl</kbd>
                      <span className="text-gray-400">+</span>
                      <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs font-mono font-bold shadow-sm text-gray-600">O</kbd>
                    </div>
                  </div>

                  <div className="flex justify-between items-center py-2 border-b border-gray-100">
                    <span className="text-sm font-semibold text-gray-700">Navigate Menu</span>
                    <div className="flex gap-1">
                      <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs font-mono font-bold shadow-sm text-gray-600">↑</kbd>
                      <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs font-mono font-bold shadow-sm text-gray-600">↓</kbd>
                    </div>
                  </div>

                  <div className="flex justify-between items-center py-2 border-b border-gray-100">
                    <span className="text-sm font-semibold text-gray-700">Select Item</span>
                    <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs font-mono font-bold shadow-sm text-gray-600 w-12 text-center">Enter</kbd>
                  </div>
                </div>

                <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-100 flex items-start gap-3">
                  <Info size={18} className="text-emerald-600 shrink-0 mt-0.5" />
                  <p className="text-xs text-emerald-800 font-medium">
                    This system uses a local SQLite database. Ensure your backend server is running on port 5000 for data synchronization.
                  </p>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="p-4 bg-gray-50 border-t border-gray-100 text-right">
                <button
                  onClick={() => setIsInfoModalOpen(false)}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-6 rounded-lg text-sm transition-colors"
                >
                  Got it
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};

export default MobileSidebar;