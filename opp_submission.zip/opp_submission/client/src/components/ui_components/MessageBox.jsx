import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import { Check, CircleX, AlertTriangle, Info } from "lucide-react";

const STYLES = {
  success: {
    color: "text-emerald-800",
    bg: "bg-white",
    border: "border-emerald-200",
    progress: "bg-emerald-500",
    icon: <Check size={18} className="text-emerald-600" />,
  },
  warning: {
    color: "text-amber-800",
    bg: "bg-white",
    border: "border-amber-200",
    progress: "bg-amber-500",
    icon: <AlertTriangle size={18} className="text-amber-600" />,
  },
  info: {
    color: "text-sky-800",
    bg: "bg-white",
    border: "border-sky-200",
    progress: "bg-sky-500",
    icon: <Info size={18} className="text-sky-600" />,
  },
  error: {
    color: "text-rose-800",
    bg: "bg-white",
    border: "border-rose-200",
    progress: "bg-rose-500",
    icon: <CircleX size={18} className="text-rose-600" />,
  },
};

const MessageBox = ({
  boxMessage,
  type = "success",
  onClose,
  duration = 3000,
}) => {
  if (!boxMessage) return null;

  // Start at 100% width
  const [isActive, setIsActive] = useState(false);
  const style = STYLES[type] || STYLES.success;

  useEffect(() => {
    // Small delay to ensure the DOM has rendered before starting transition
    const animationTimeout = setTimeout(() => setIsActive(true), 10);

    const closeTimer = setTimeout(() => {
      if (onClose) onClose();
    }, duration);

    return () => {
      clearTimeout(animationTimeout);
      clearTimeout(closeTimer);
    };
  }, [duration, onClose, boxMessage]);

  return (
    <div className="fixed bottom-6 right-6 z-[100] animate-in fade-in slide-in-from-right-8 duration-300">
      <div className={`relative overflow-hidden min-w-[320px] shadow-2xl border ${style.bg} ${style.border}`}>
        
        {/* Main Content */}
        <div className="flex items-center gap-4 px-5 py-4">
          <div className="shrink-0">{style.icon}</div>
          <p className={`text-sm font-bold uppercase tracking-tight ${style.color}`}>
            {boxMessage}
          </p>
        </div>

        {/* CSS-Driven Progress Line */}
        <div className="absolute bottom-0 left-0 h-1 w-full bg-gray-100/50">
          <div 
            className={`h-full ${style.progress}`}
            style={{ 
              width: isActive ? "0%" : "100%", 
              transition: isActive ? `width ${duration}ms linear` : "none" 
            }}
          />
        </div>
      </div>
    </div>
  );
};

MessageBox.propTypes = {
  boxMessage: PropTypes.string,
  type: PropTypes.oneOf(["success", "error", "warning", "info"]),
  onClose: PropTypes.func.isRequired,
  duration: PropTypes.number,
};

export default MessageBox;