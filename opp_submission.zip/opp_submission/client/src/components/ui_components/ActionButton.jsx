// Lightweight, reusable action button component
// - Acts like a normal button by default
// - If `to` is provided (and no `onClick`), it navigates via react-router
// - Shows a spinner when `loading` is true and prevents interaction
// - Respects `disabled` and prevents navigation/clicks when disabled
import { Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import React from "react";
import PropTypes from "prop-types";

/**
 * ActionButton
 * A flexible button that can:
 *  - run a custom onClick handler, or
 *  - navigate to a route via `to` when no onClick is provided.
 * It guards interactions while loading/disabled and shows a spinner when loading.
 */
const ActionButton = ({
  type = "button",
  label = "Click Me",
  to = null,
  state = null,
  onClick = null,
  loading = false,
  disabled = false,
  className = "",
  children = null,
  tooltip = "",
  ariaLabel = "",
  rectangular = false,
}) => {
  const resolvedAriaLabel = ariaLabel || label;
  const navigate = useNavigate();

  const handleClick = (e) => {
    // Block interaction when loading/disabled to avoid duplicate actions
    if (loading || disabled) return;

    // Prefer explicit onClick if provided
    if (onClick) {
      onClick(e);
    } else if (to) {
      // Fallback to navigation when `to` is supplied and no onClick
      navigate(to, { state });
    }
  };

  return (
    <div className="relative inline-block group">
      <button
        type={type}
        onClick={handleClick}
        disabled={disabled || loading}
        aria-label={resolvedAriaLabel}
        // Base styles + conditional states and variants
        className={`flex items-center justify-center gap-2 px-4 py-2 ${rectangular ? "rounded-md" : "rounded-full"}
                    text-black font-semibold transition-all duration-200 shadow-sm
                    whitespace-nowrap text-ellipsis overflow-hidden
                    ${
                      disabled || loading
                        ? "opacity-60 cursor-not-allowed"
                        : "hover:brightness-110 hover:shadow-md"
                    }
                    ${
                      // Opt-in "danger" look by passing "danger" in className
                      className?.includes("danger")
                        ? "bg-primary/60 text-black/90"
                        : "bg-dark text-white"
                    }
                    ${className}
                    sm:px-5 sm:py-2.5 sm:text-base text-sm`}
      >
        {/* Inline spinner while performing async actions */}
        {loading && <Loader2 size={18} className="animate-spin text-current" />}
        {children ? (
          // Allow fully custom content when children are passed
          children
        ) : (
          // Default to a single-line truncated label
          <span className="truncate max-w-[80vw]">{label}</span>
        )}
      </button>

      {tooltip && (
        <div
  className="
    pointer-events-none absolute left-1/2 -translate-x-1/2 
    translate-y-2 
    opacity-0 
    group-hover:opacity-100 
    group-hover:translate-y-2 
    transition-all duration-150 ease-out 
    bg-gray-800 text-white text-xs rounded 
    px-2 py-1 shadow-lg whitespace-nowrap z-10
  "
  role="tooltip"
>

          {tooltip}
        </div>
      )}
    </div>
  );
};
ActionButton.propTypes = {
  type: PropTypes.string,               // Button type: "button", "submit", etc.
  label: PropTypes.string,              // Text label when no children are provided
  to: PropTypes.string,                 // Optional route path to navigate to
  state: PropTypes.any,                 // Optional navigation state passed to router
  onClick: PropTypes.func,              // Click handler; takes precedence over `to`
  loading: PropTypes.bool,              // Shows spinner and disables interactions
  disabled: PropTypes.bool,             // Disables button interactions and hovers
  className: PropTypes.string,          // Extra classes; include "danger" to switch variant
  children: PropTypes.node,             // Custom content; overrides `label`
  tooltip: PropTypes.string,            // Optional tooltip text to show on hover
  ariaLabel: PropTypes.string,          // Optional aria-label for assistive tech
  rectangular: PropTypes.bool,          // If true, uses rectangular (rounded-md) shape instead of pill
};

export default ActionButton;
