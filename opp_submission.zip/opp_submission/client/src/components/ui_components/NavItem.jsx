import { Link, useLocation } from "react-router-dom";
import React from "react";
import PropTypes from "prop-types";

// Sidebar navigation item rendered as a React Router Link
const NavItem = React.forwardRef(
  (
    // Notice we rename 'icon' to 'Icon' (capitalized) so React knows it's a component
    { icon: Icon, text, path, isOpen, setIsOpen, onFocus },
    ref
  ) => {
    const location = useLocation();
    const isActive = location.pathname === path;

    return (
      <Link
        ref={ref}
        to={path}
        aria-current={isActive ? "page" : undefined}
        aria-label={text}
        className={`flex items-center gap-7 cursor-pointer w-full px-2 py-2 rounded-lg transition-all duration-300
          ${
            isActive
              ? "bg-dark text-white shadow-md"
              : "text-textWhite hover:bg-dark hover:text-white"
          }
        `}
        onClick={() => setIsOpen(false)}
        onFocus={onFocus}
      >
        <span
          data-tooltip-id={!isOpen ? "sidebar-tooltip" : undefined}
          data-tooltip-content={!isOpen ? text : undefined}
          className="relative flex-shrink-0 flex items-center justify-center"
        >
          {/* We now render the icon component with a consistent size */}
          <Icon size={24} />
        </span>

        {/* Added whitespace-nowrap to prevent text wrapping during sidebar open/close animation */}
        {isOpen && <div className="text-sm font-medium whitespace-nowrap">{text}</div>}
      </Link>
    );
  }
);

NavItem.displayName = "NavItem";

NavItem.propTypes = {
  icon: PropTypes.elementType.isRequired, // Changed from node to elementType
  text: PropTypes.string.isRequired,
  path: PropTypes.string.isRequired,
  isOpen: PropTypes.bool.isRequired,
  setIsOpen: PropTypes.func.isRequired,
  onFocus: PropTypes.func,
};

export default NavItem;