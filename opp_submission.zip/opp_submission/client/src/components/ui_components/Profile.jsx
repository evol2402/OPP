import React, { useState, useEffect, useRef } from "react";
import { User, LogOut } from "lucide-react";
import PropTypes from "prop-types";

const Profile = ({ username = "Admin", role = "Project Manager" }) => {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Mock action handler for the assessment
  const handleMockAction = (actionName) => {
    alert(`${actionName} clicked! (This is a static mock UI for the assessment)`);
    setOpen(false);
  };

  return (
    <div className="relative inline-block text-left" ref={menuRef}>
      
      {/* Avatar Button */}
      <button
        onClick={() => setOpen((prev) => !prev)}
        className="focus:outline-none relative group flex items-center gap-3"
      >
        <div className="hidden sm:block text-right text-white mr-1">
          <p className="text-sm font-bold tracking-wide">{username}</p>
          <p className="text-xs text-gray-200">{role}</p>
        </div>
        
        <div className="inline-block rounded-full p-1 transition duration-300 hover:ring-2 hover:ring-white hover:scale-105">
          <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-xl font-bold text-emerald-700 shadow-md">
            {username.charAt(0).toUpperCase()}
          </div>
        </div>
      </button>

      {/* Dropdown Menu */}
      <div
        className={`absolute right-0 mt-3 w-48 z-50 bg-white border border-gray-200 rounded-lg shadow-lg py-2 transform transition-all duration-200 ease-out origin-top-right ${
          open
            ? "opacity-100 scale-100 pointer-events-auto"
            : "opacity-0 scale-95 pointer-events-none"
        }`}
      >
        {/* Profile Option */}
        <button
          className="flex items-center gap-3 w-full px-4 py-2 text-gray-700 hover:bg-gray-100 transition-colors text-left outline-none"
          onClick={() => handleMockAction("View Profile")}
        >
          <User size={16} className="text-gray-500" />
          <span className="text-sm font-medium">View Profile</span>
        </button>

        {/* Logout Option */}
        <button
          className="flex items-center gap-3 w-full px-4 py-3 text-red-600 hover:bg-red-50 transition-colors text-left outline-none border-t border-gray-100 mt-1"
          onClick={() => handleMockAction("Sign Out")}
        >
          <LogOut size={16} />
          <span className="text-sm font-medium">Sign Out</span>
        </button>
      </div>
      
    </div>
  );
};

Profile.propTypes = {
  username: PropTypes.string,
  role: PropTypes.string,
};

export default Profile;