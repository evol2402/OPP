import React from "react";
import PropTypes from "prop-types";

const TitleBox = ({
  title = "Section Title",
  color = "red",
  children,
  className = "",
  minimal = false, // New prop
}) => {
  return (
    <div
      className={`
        p-4 shadow-sm transition-all mb-3
        ${minimal 
          ? "bg-gray-200 border-none shadow-none" 
          : `bg-white border border-black border-l-[6px] ${className}`
        }
      `}
      style={!minimal ? { borderLeftColor: color } : {}}
    >
      <h2 className={`text-xl font-semibold text-black ${children ? "mb-1" : ""}`}>
        {title}
      </h2>
      {children && <div className="text-black">{children}</div>}
    </div>
  );
};

TitleBox.propTypes = {
  title: PropTypes.string,
  color: PropTypes.string,
  children: PropTypes.node,
  className: PropTypes.string,
  minimal: PropTypes.bool,
};

export default TitleBox;