import React, { useEffect, useState } from "react";
import { X, Keyboard } from "lucide-react";

const SHORTCUTS = [
  { key: "Ctrl + O", desc: "Toggle Sidebar" },
  { key: "Ctrl + D", desc: "Focus Search" },
  { key: "Alt + P", desc: "Open Profile Menu" },
  { key: "Alt + T", desc: "Open Logout Modal" },
  { key: "Ctrl + /", desc: "Show Shortcuts" },
  { key: "Alt + c", desc: "Open Speed Dial" },
];

const KeyboardShortcuts = () => {
  const [open, setOpen] = useState(false);

  // Toggle with Ctrl + /   (or Cmd + / on Mac)
  useEffect(() => {
    const handleKey = (e) => {
      const isInput =
        e.target.tagName === "INPUT" ||
        e.target.tagName === "TEXTAREA" ||
        e.target.isContentEditable;

      if (isInput) return;

      if ((e.ctrlKey || e.metaKey) && e.key === "/") {
        e.preventDefault();
        setOpen((prev) => !prev);
      }

      if (e.key === "Escape") {
        setOpen(false);
      }
    };

    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[999] flex items-center justify-center bg-black/40 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6 animate-fade-in">
        
        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <Keyboard className="text-emerald-600" />
            <h2 className="text-lg font-bold text-black">
              Keyboard Shortcuts
            </h2>
          </div>

          <button
            onClick={() => setOpen(false)}
            className="hover:bg-gray-100 p-1 rounded-full"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Shortcuts List */}
        <ul className="space-y-3">
          {SHORTCUTS.map((item, idx) => (
            <li
              key={idx}
              className="flex items-center justify-between text-sm"
            >
              <span className="text-gray-700">{item.desc}</span>

              <kbd className="px-2 py-1 bg-gray-100 border rounded-md text-gray-800 font-mono text-xs">
                {item.key}
              </kbd>
            </li>
          ))}
        </ul>

        {/* Footer */}
        <div className="mt-6 text-xs text-center text-gray-500">
          Press <b>Esc</b> to close
        </div>
      </div>
    </div>
  );
};

export default KeyboardShortcuts;
