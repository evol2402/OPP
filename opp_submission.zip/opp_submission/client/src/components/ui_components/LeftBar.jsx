﻿import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, LayoutDashboard, FolderKanban, Info, X, Keyboard } from "lucide-react";
import { Tooltip } from "react-tooltip";
import NavItem from "../ui_components/NavItem"; 

const menuItems = [
  { icon: LayoutDashboard, text: "Dashboard", path: "/dashboard" },
  { icon: FolderKanban, text: "Projects", path: "/projects" },
];

const LeftBar = () => {
  const [width, setWidth] = useState(200);
  const [isOpen, setIsOpen] = useState(false);
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false);

  const itemRefs = useRef([]);
  const [activeIndex, setActiveIndex] = useState(0);

  // Responsive width logic
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 640) {
        setWidth(isOpen ? 150 : 50);
      } else if (window.innerWidth < 1024) {
        setWidth(isOpen ? 180 : 60);
      } else {
        setWidth(isOpen ? 240 : 60);
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);

    return () => window.removeEventListener("resize", handleResize);
  }, [isOpen]);

  // Ctrl + O and Arrow Navigation
  useEffect(() => {
    const handleKeyDown = (e) => {
      const isInput =
        e.target.tagName === "INPUT" ||
        e.target.tagName === "TEXTAREA" ||
        e.target.isContentEditable;

      if (isInput) return;

      if ((e.ctrlKey || e.metaKey) && (e.key === "o" || e.key === "O")) {
        e.preventDefault();
        setIsOpen((prev) => {
          const next = !prev;
          if (next) setActiveIndex(0);
          return next;
        });
        return;
      }

      if (isOpen) {
        if (e.key === "ArrowDown" || e.key === "ArrowUp") {
          e.preventDefault(); 
          setActiveIndex((prev) => {
            if (e.key === "ArrowDown") {
              return Math.min(prev + 1, menuItems.length - 1);
            } else {
              return Math.max(prev - 1, 0);
            }
          });
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const node = itemRefs.current[activeIndex];
    node?.focus();
  }, [isOpen, activeIndex]);

  useEffect(() => {
    itemRefs.current = itemRefs.current.slice(0, menuItems.length);
    setActiveIndex((prev) =>
      menuItems.length === 0 ? 0 : Math.min(prev, menuItems.length - 1)
    );
  }, []);

  return (
    <>
      {/* THE FIX: Changed to absolute inset-y-0 left-0 */}
      <div className="hidden sm:block absolute inset-y-0 left-0 z-40">
        <motion.div
          initial={{ width: 60 }}
          animate={{ width }}
          transition={{ duration: 0.4 }}
          // Removed gap-6, ensured flex-col and h-full
          className="bg-sidebar h-full text-textWhite p-2 flex flex-col shadow-xl"
        >
          {/* Expand/Collapse Button */}
          <button
            className={`flex items-center justify-center gap-3 px-0 py-2 
            cursor-pointer w-12 h-12 mt-4 shrink-0
            bg-dark text-textWhite rounded-lg 
            hover:scale-105 hover:shadow-lg hover:shadow-gray-700/50 
            transition-all duration-500 ease-in-out
            ${isOpen ? "sm:ml-36 md:ml-[150px] lg:ml-[210px]" : "ml-5"}
          `}
            onClick={() => setIsOpen((prev) => !prev)}
            aria-label="Side-Button"
            data-tooltip-id={!isOpen ? "expand-tooltip" : undefined}
            data-tooltip-content={!isOpen ? "Expand (Ctrl + O)" : ""}
          >
            {isOpen ? <ChevronLeft /> : <ChevronRight />}
          </button>

          {/* Sidebar Menu - Added mt-6 to replace the old gap-6 spacing */}
          <nav
            className={`flex-1 flex flex-col gap-5 mt-6 overflow-y-auto overflow-x-hidden ${
              !isOpen && "no-scrollbar"
            }`}
          >
            {menuItems.map((item, index) => (
              <NavItem
                key={index}
                ref={(el) => (itemRefs.current[index] = el)}
                icon={item.icon}
                text={item.text}
                path={item.path}
                isOpen={isOpen}
                setIsOpen={setIsOpen}
                onFocus={() => setActiveIndex(index)}
              />
            ))}
          </nav>

          {/* Bottom Info Icon - shrink-0 guarantees it never gets crushed */}
          <div className="mt-auto border-t border-white/10 pt-3 pb-2 shrink-0">
            <button
              onClick={() => setIsInfoModalOpen(true)}
              className={`flex items-center p-3 rounded-lg w-full text-gray-400 hover:text-white hover:bg-white/10 transition-colors ${
                isOpen ? "justify-start gap-4 px-4" : "justify-center"
              }`}
              data-tooltip-id={!isOpen ? "sidebar-tooltip" : undefined}
              data-tooltip-content="System Info & Shortcuts"
            >
              <Info size={22} className="shrink-0" />
              {isOpen && <span className="font-semibold text-sm whitespace-nowrap">Help & Info</span>}
            </button>
          </div>
        </motion.div>

        {/* Tooltips */}
        {!isOpen && <Tooltip id="sidebar-tooltip" place="right" offset={20} className="z-50" />}
        <Tooltip id="expand-tooltip" place="right" offset={20} className="z-50" />
      </div>

      {/* Info Modal */}
      <AnimatePresence>
        {isInfoModalOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col"
            >
              <div className="bg-gray-50 px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                <div className="flex items-center gap-2 text-gray-800 font-black uppercase tracking-tight">
                  <Keyboard size={20} className="text-emerald-600" />
                  System Shortcuts
                </div>
               
              </div>

              <div className="p-6 space-y-6">
                <p className="text-sm text-gray-600 leading-relaxed">
                  Navigate the dashboard more efficiently using these built-in keyboard shortcuts.
                </p>

                <div className="space-y-3">
                  <div className="flex justify-between items-center py-2 border-b border-gray-100">
                    <span className="text-sm font-semibold text-gray-700">Toggle Sidebar</span>
                    <div className="flex gap-1">
                      <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs font-mono font-bold shadow-sm text-gray-600">Ctrl</kbd>
                      <span className="text-gray-400">+</span>
                      <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs font-mono font-bold shadow-sm text-gray-600">O</kbd>
                    </div>
                  </div>

                  <div className="flex justify-between items-center py-2 border-b border-gray-100">
                    <span className="text-sm font-semibold text-gray-700">Navigate Menu</span>
                    <div className="flex gap-1">
                      <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs font-mono font-bold shadow-sm text-gray-600">↑</kbd>
                      <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs font-mono font-bold shadow-sm text-gray-600">↓</kbd>
                    </div>
                  </div>

                  <div className="flex justify-between items-center py-2 border-b border-gray-100">
                    <span className="text-sm font-semibold text-gray-700">Select Item</span>
                    <kbd className="px-2 py-1 bg-gray-100 border border-gray-300 rounded text-xs font-mono font-bold shadow-sm text-gray-600 w-12 text-center">Enter</kbd>
                  </div>
                </div>

                <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-100 flex items-start gap-3">
                  <Info size={18} className="text-emerald-600 shrink-0 mt-0.5" />
                  <p className="text-xs text-emerald-800 font-medium">
                    This system uses a local SQLite database. Ensure your backend server is running on port 5000 for data synchronization.
                  </p>
                </div>
              </div>

              <div className="p-4 bg-gray-50 border-t border-gray-100 text-right">
                <button
                  onClick={() => setIsInfoModalOpen(false)}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-6 rounded-lg text-sm transition-colors"
                >
                  Got it
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};

export default LeftBar;