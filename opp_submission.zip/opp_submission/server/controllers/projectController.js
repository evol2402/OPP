// backend/controllers/projectController.js
import sqlite3 from "sqlite3";
import path from "path";
import { fileURLToPath } from "url";

// 1. Setup Database Connection
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure this path matches exactly where your .sqlite file actually lives!
const dbPath = path.join(process.cwd(), "database", "projects.db");

const db = new sqlite3.Database(dbPath, sqlite3.OPEN_READWRITE, (err) => {
  if (err) {
    console.error("❌ Error connecting to SQLite database:", err.message);
  } else {
    console.log("✅ Connected to the SQLite projects database.");
  }
});

// READ: Get all projects
export const getAllProjects = (req, res) => {
  const sql = `SELECT * FROM projects ORDER BY id DESC`;
  
  db.all(sql, [], (err, rows) => {
    if (err) {
      console.error("Fetch Error:", err.message);
      return res.status(500).json({ error: "Failed to fetch projects" });
    }
    res.json(rows);
  });
};

// CREATE: Add a new project
export const createProject = (req, res) => {
  const { project_name, bureau, status, priority, start_date, end_date, description, budget } = req.body;
  
  // Basic Backend Validation
  if (!project_name) {
    return res.status(400).json({ error: "Project name is required." });
  }

  const sql = `
    INSERT INTO projects (project_name, bureau, status, priority, start_date, end_date, description, budget)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `;
  
  // Default budget to 0 if not provided
  const params = [project_name, bureau, status, priority, start_date, end_date, description, budget || 0];

  db.run(sql, params, function(err) {
    if (err) {
      console.error("Create Error:", err.message);
      return res.status(500).json({ error: "Failed to create project" });
    }
    res.status(201).json({ 
      id: this.lastID, 
      project_name, bureau, status, priority, start_date, end_date, description, budget: budget || 0 
    });
  });
};

// UPDATE: Edit an existing project
export const updateProject = (req, res) => {
  const { id } = req.params;
  const { project_name, bureau, status, priority, start_date, end_date, description, budget } = req.body;

  if (!project_name) {
    return res.status(400).json({ error: "Project name is required." });
  }

  const sql = `
    UPDATE projects 
    SET project_name = ?, bureau = ?, status = ?, priority = ?, start_date = ?, end_date = ?, description = ?, budget = ?
    WHERE id = ?
  `;
  const params = [project_name, bureau, status, priority, start_date, end_date, description, budget || 0, id];

  db.run(sql, params, function(err) {
    if (err) {
      console.error("Update Error:", err.message);
      return res.status(500).json({ error: "Failed to update project" });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: "Project not found" });
    }
    res.json({ message: "Project updated successfully" });
  });
};

// DELETE: Remove a project
export const deleteProject = (req, res) => {
  const { id } = req.params;
  const sql = `DELETE FROM projects WHERE id = ?`;

  db.run(sql, id, function(err) {
    if (err) {
      console.error("Delete Error:", err.message);
      return res.status(500).json({ error: "Failed to delete project" });
    }
    if (this.changes === 0) {
      return res.status(404).json({ error: "Project not found" });
    }
    res.json({ message: "Project deleted successfully", id });
  });
};