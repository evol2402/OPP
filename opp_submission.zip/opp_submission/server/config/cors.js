import cors from "cors";

// 1. Define your core allowed origins (Local dev + Production)
const allowedOrigins = [
  "http://localhost:5173",
  "http://localhost:5000",
];


export const corsMiddleware = cors({
  origin: (origin, callback) => {
    // Allow requests with no origin (like Postman or curl) OR if it's in our list
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      console.warn(`[CORS] Blocked origin: ${origin}`);
      callback(new Error("Not allowed by CORS"));
    }
  },
  credentials: true, // Needed if you are sending cookies/tokens
});

export default corsMiddleware;