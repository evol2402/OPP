// backend/config/env.js
import dotenv from "dotenv";

// Load environment variables from the .env file
dotenv.config();

// Export the port, defaulting to 5000 if not set in the .env file
export const PORT = process.env.PORT || 5000;