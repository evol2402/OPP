// backend/server.js
import "./config/env.js";
import path from "path";
import { existsSync } from "fs";
import { fileURLToPath } from "url";
import express from "express";
import cors from "cors";
import { PORT } from "./config/env.js";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler.js";

// Built this single route file next
import projectRoutes from "./routes/projectRoutes.js"; 

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const clientDistPath = path.join(__dirname, "./dist");
const clientIndexFile = path.join(clientDistPath, "index.html");

const app = express();

// Middleware
app.use(cors()); // Simplified CORS
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


// Routes - Everything project-related goes here
app.use("/api/projects", projectRoutes);

// Serve React Frontend (if built)
if (existsSync(clientIndexFile)) {
  app.use(express.static(clientDistPath));
  app.use((req, res, next) => {
    const isApiPath = req.path.startsWith("/api");
    const isFileRequest = /\.[a-zA-Z0-9]+$/.test(req.path);
    if (isApiPath || isFileRequest) return next();
    res.sendFile(clientIndexFile);
  });
}

// Error handlers
app.use(notFoundHandler);
app.use(errorHandler);

// Start server (No DB connection delay needed for SQLite)
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || "development"}`);
});