import sqlite3 from 'sqlite3';
import path from 'path';

// 1. Point this to your actual database file location
// If your db is in a "database" folder, use this:
const dbPath = path.resolve('../database/projects.db'); 
// (If it's just in the same folder as this script, use: './projects.db')

// 2. Connect to the database
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error("❌ Failed to connect to the database:", err.message);
    process.exit(1);
  }
  console.log("✅ Connected to the database.");
});

// 3. The SQL Query to add the budget column
const sql = `ALTER TABLE projects ADD COLUMN budget REAL DEFAULT 0.0`;

console.log("Attempting to add 'budget' column...");

// 4. Execute the query with Error Handling
db.run(sql, (err) => {
  if (err) {
    // Check if the error is just because the column is already there
    if (err.message.includes("duplicate column name")) {
      console.log("⚠️  Action skipped: The 'budget' column ALREADY EXISTS in the table.");
    } else {
      console.error("❌ Critical Error updating database:", err.message);
    }
  } else {
    console.log("🎉 SUCCESS! The 'budget' column has been successfully added.");
  }
  
  // 5. Safely close the database connection
  db.close((err) => {
    if (err) {
      console.error("❌ Error closing database:", err.message);
    } else {
      console.log("🔒 Database connection closed.");
    }
  });
});