export const errorHandler = (err, req, res, _next) => {
  console.error(`[${req.id}] Unhandled error:`, err);

  const status = err.status || err.statusCode || 500;
  const message = err.message || "Internal server error";

  res.status(status).json({
    success: false,
    message: status >= 500 ? "Internal server error" : message,
    requestId: req.id,
  });
};

export const notFoundHandler = (req, res) => {
  res.status(404).json({
    success: false,
    message: "Route not found",
    requestId: req.id,
  });
};

